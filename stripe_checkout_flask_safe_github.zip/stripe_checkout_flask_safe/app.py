import os
from urllib.parse import urlparse

from flask import Flask, redirect, jsonify

app = Flask(__name__)

CHECKOUT_URL = os.environ.get("STRIPE_CHECKOUT_URL", "").strip()


def valid_checkout_url(url: str) -> bool:
    parsed = urlparse(url)
    return (
        parsed.scheme == "https"
        and parsed.hostname == "checkout.stripe.com"
        and not parsed.username
        and not parsed.password
    )


@app.get("/")
def home():
    if not CHECKOUT_URL or not valid_checkout_url(CHECKOUT_URL):
        return (
            "Checkout is not configured. Set STRIPE_CHECKOUT_URL to your "
            "official Stripe Checkout URL.",
            503,
        )
    # Send the customer directly to Stripe. This app never handles card data.
    return redirect(CHECKOUT_URL, code=303)


@app.get("/health")
def health():
    return jsonify(status="ok")


if __name__ == "__main__":
    # For local development only. Use a production WSGI server when deployed.
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
