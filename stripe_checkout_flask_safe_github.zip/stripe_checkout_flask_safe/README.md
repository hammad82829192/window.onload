# Safe Stripe Checkout Redirect (Flask)

A small Flask app that redirects visitors to an official Stripe Checkout URL.
It does **not** proxy Stripe pages, inspect checkout forms, collect card details,
or send payment information to another server.

## Requirements

- Python 3.10+
- A legitimate Stripe Checkout URL created through your Stripe account

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
# Windows: .venv\\Scripts\\activate

pip install -r requirements.txt
```

Set the checkout URL as an environment variable:

```bash
export STRIPE_CHECKOUT_URL="https://checkout.stripe.com/your-checkout-session"
# Windows PowerShell:
# $env:STRIPE_CHECKOUT_URL="https://checkout.stripe.com/your-checkout-session"
```

Start the app:

```bash
python app.py
```

Open http://127.0.0.1:5000/

## GitHub upload

Create an empty repository on GitHub, then run these commands from this folder:

```bash
git init
git add .
git commit -m "Add safe Stripe Checkout redirect app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own GitHub repository URL.

## Security notes

- Never commit `.env` files, API keys, or private Stripe secrets.
- Do not ask customers to enter card details into this Flask app.
- Use Stripe's official Checkout and webhook documentation for payment status.
- The built-in Flask server is for local development, not production.
