import os
from urllib.parse import urlparse

from flask import Flask, redirect, jsonify

app = Flask(__name__)

CHECKOUT_URL = os.environ.get("STRIPE_CHECKOUT_URL", "").strip()


def valid_checkout_url(url: str) -> bool:
    parsed = urlparse(url)
    return (
        parsed.scheme == "https"
        and parsed.hostname == "checkout.stripe.com"
        and not parsed.username
        and not parsed.password
    )


@app.get("/")
def home():
    if not CHECKOUT_URL or not valid_checkout_url(CHECKOUT_URL):
        return (
            "Checkout is not configured. Set STRIPE_CHECKOUT_URL in the "
            "hosting provider's environment variables.",
            503,
        )
    return redirect(CHECKOUT_URL, code=303)


@app.get("/health")
def health():
    return jsonify(status="ok")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
