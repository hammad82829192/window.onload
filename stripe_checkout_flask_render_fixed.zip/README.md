# Safe Stripe Checkout Redirect

A minimal Flask app that redirects visitors to a legitimate Stripe Checkout URL.
It does not copy Stripe's HTML, inspect checkout forms, collect card details,
or transmit payment information.

## Deploy on Render

1. Push these files to a GitHub repository.
2. In Render, choose **New → Web Service** and connect the repository.
3. Render can use the included `render.yaml`. Otherwise set:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
4. In Render's Environment settings, add:
   - Key: `STRIPE_CHECKOUT_URL`
   - Value: your legitimate Stripe Checkout URL
5. Deploy.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export STRIPE_CHECKOUT_URL="https://checkout.stripe.com/your-checkout-session"
gunicorn app:app
```

Open `http://127.0.0.1:8000/` locally if you run Gunicorn with its default port,
or use `gunicorn --bind 127.0.0.1:5000 app:app`.

## Security

Never commit API keys or `.env` files. Keep card entry and payment processing
on Stripe's official hosted Checkout page.
